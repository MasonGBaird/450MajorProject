import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/*
 * Vaccination Culture Calculator 
 * 
 * This program was designed to take in a country
 * and give out specific information including Approval Rating, Important For
 * Children, If its safe, and how Effective it is with the country selected. You
 * can also click See or Insert a new user by clicking the button that says see
 * or import user. Just as the window described above, you have to select a user
 * on a drop down menu, where the username email, phone nmber, and Vaccination
 * Stance will appear. From this window, you can go back to the main screen or
 * insert a user by clicking insert a user. Once in the Insert a user screen you
 * can put in the information of a user and click insert or go back
 *  
 * Maggie Malia and Taylor Clark
 * 
 * Date Created:11/20/19
 * Last Updated:11/20/10
 *
 */

public class Main_UI extends JFrame implements ActionListener, ItemListener {

	public String[] listToArray(ArrayList<String> list) {
		/**
		 * 
		 * creates main user interface that will be implimaented in main method. calls
		 * each card to create full interface
		 * 
		 */

		String[] array = new String[list.size()];
		for (int i = 0; i < list.size(); i++) {

			array[i] = list.get(i);

		}

		return array;

	}

	JPanel panels;
	String[] panelNames = { "mainPanel", "userPanel", "insertUserPanel" };
	int currentPanel;
	// CurrentPanel is being used to keep track of what Panel we are on
	JPanel spacer = new JPanel();
	// This panel is used as a spacer panel, to keep everything looking nice
	Queries q = new Queries();
	// This is used to interact with the class Queries

	JPanel mainCard;
	JPanel userCard;
	JPanel insertCard;
	// This are the Panels being used for the Cardlayout, so that we can change the
	// windows without creating a new one

	public Main_UI( String title) 
	{
		super(title);
		
		currentPanel = 0;
		// We set the current panel to 0 to initilize it
		panels = new JPanel();
		panels.setLayout(new CardLayout());
		// This sets the layout to the CardLayout

		mainCard = MainPanel();
		userCard = UserPanel();
		insertCard = InsertUserPanel();
		// we are intilizing the cards used for the card layout

		panels.add(mainCard, "mainPanel");
		panels.add(userCard, "userPanel");
		panels.add(insertCard, "insertUserPanel");
		// we add the cards, initilzed earlier to the panel

		add(panels);
		// we add the panel to the frame

		CardLayout c1 = (CardLayout) (panels.getLayout());
		c1.show(panels, panelNames[0]);
		;
		// we create and object of the cardlayout to interact with it
		// we also show the very MainLayout with the country information

	}

	// Various cards that will be in main UI
	/**
	 * main panel -Dynamic JComboBox selection for counties -5 static JLabel
	 * (Approval rating [-10 - 10]:, SA Important for Children:, SA Safe:, SD
	 * Effective:) -5 dynamic JLabels that update on the CountryComboBox Selection
	 * and reflect selected countries data -JButton that adjusts panel visibilities
	 * ("See or insert user")
	 */
	private String CountryString, ApprovalString, ImportantString, SafeString, EffectiveString;
	// here are the strings that hold the country information
	private JComboBox SelectCountryMenu;
	// this is the JComboBox being used to select which country you want to display
	// the information of
	private JLabel SelectCountry, CountrySelected = new JLabel(CountryString), ApprovalRating, ImportantForChildern,
			Safe, Effective, ApprovalRatingAnswer = new JLabel(ApprovalString),
			ImportantForChildernAnswer = new JLabel(ImportantString), SafeAnswer = new JLabel(SafeString),
			EffectiveAnswer = new JLabel(EffectiveString);
	// These are all of the Jlabels being used to hold Information, which includes
	// the Approval Rating, Important for children, If its safe, and If it is
	// effective in that country
	JPanel mainPanel, countryInfoPanel, CountrySelectedPanel, ApprovalRatingPanel, ImportantForChildernPanel, SafePanel,
			EffectivePanel;
	//These are all of the panels being used to display the information in a nice formatting
	JButton toUser;
	//This is the button used to switch which card is visible in the cardLayout

	private JPanel MainPanel() {

		mainPanel = new JPanel();
		mainPanel.setLayout(new GridLayout(1, 2));
		//We crate a main panel with 1 row and 2 Columns

		selectionPanel = new JPanel(new GridLayout(2, 1)); // right side of panel
		topSelectionPanel = new JPanel(new GridLayout(3, 1));// top half of right panel
		comboPanel = new JPanel(new GridLayout(1, 2));// holds combobox, put in topSelectionPanel
		JPanel ques = new JPanel();
		JPanel box = new JPanel();
		//Initilizating the JPanels

		SelectCountryMenu = new JComboBox(listToArray(q.populateCountryCombo()));
		//Populates the CountryMenu JComboBox
		SelectCountryMenu.setSelectedIndex(0);
		//Starts off at the 0th place of the Array that was turned into a list
		SelectCountryMenu.addItemListener(this);

		SelectCountry = new JLabel("Select Country: ");
		//Creates a label called Select Country 

		ques.add(SelectCountry);
		//we add selectCountry to the Ques Jpanel
		box.add(SelectCountryMenu);
		//we ad the selectCountryMenu to the box panel
		comboPanel.add(ques);
		comboPanel.add(box);
		//we add both the JPanels, ques and box, to the combopanel

		JPanel blank = new JPanel();
		topSelectionPanel.add(blank);
		topSelectionPanel.add(comboPanel);
		//we create a JPanel called blank and add blank and the combopanel to the top selection panel

		selectionPanel.add(topSelectionPanel);
		//We add topselectionpanel to the selectionPanel

		toUser = new JButton("Inster or See User ");
		toUser.addActionListener(this);
		//we create a button that takes us to the userPanel

		buttonPanel = new JPanel();
		buttonPanel.add(toUser);
		//we add the buttion to user to a panel

		selectionPanel.add(buttonPanel);
		//we add the button to the selectionpanel

		mainPanel.add(selectionPanel);
		//we add the slection panel to the main panel

		countryInfoPanel = new JPanel(new GridLayout(5, 1));
		//thisis used to crate the countryinfo panel with a gridlayout, having 5 rows and 1 column

		ApprovalRating = new JLabel("Approval Rating [-10 - 10]:     ");
		ImportantForChildern = new JLabel("SA Important for Children:      ");
		Safe = new JLabel("SA Safe:                        ");
		Effective = new JLabel("SA Effective:                   ");
		//we initlize the JLabels with their information

		ArrayList info = q.fetchCRecord((String) SelectCountryMenu.getSelectedItem());
		//We take in the user info from the method fetchCRecord

		ApprovalRatingAnswer = new JLabel((String) info.get(1));
		ImportantForChildernAnswer = new JLabel((String) info.get(2));
		SafeAnswer = new JLabel((String) info.get(3));
		EffectiveAnswer = new JLabel((String) info.get(4));
		//we set the information pertaining to the question respectively

		CountrySelected.setText((String) SelectCountryMenu.getSelectedItem());
		CountrySelected.setFont(new Font("Arial", Font.BOLD, 15));
		//we set country selected and its font
		ApprovalRatingPanel = new JPanel(new GridLayout(1, 2));
		ImportantForChildernPanel = new JPanel(new GridLayout(1, 2));
		SafePanel = new JPanel(new GridLayout(1, 2));
		EffectivePanel = new JPanel(new GridLayout(1, 2));
		CountrySelectedPanel = new JPanel(new BorderLayout());
		//we have a separate panel for each response, creating Gridlayoust when needed for spacing

		CountrySelectedPanel.add(CountrySelected, BorderLayout.CENTER);
		ApprovalRatingPanel.add(ApprovalRating);
		ImportantForChildernPanel.add(ImportantForChildern);
		SafePanel.add(Safe);
		EffectivePanel.add(Effective);
		//we add the Static JLabels to their panels

		ApprovalRatingPanel.add(ApprovalRatingAnswer);
		ImportantForChildernPanel.add(ImportantForChildernAnswer);
		SafePanel.add(SafeAnswer);
		EffectivePanel.add(EffectiveAnswer);
		//we add the dynamic JLabels to their panels

		countryInfoPanel.add(CountrySelectedPanel);
		countryInfoPanel.add(ApprovalRatingPanel);
		countryInfoPanel.add(ImportantForChildernPanel);
		countryInfoPanel.add(SafePanel);
		countryInfoPanel.add(EffectivePanel);
		//we add each panel to the countryinfopanel

		mainPanel.add(countryInfoPanel, BorderLayout.EAST);
		//we add the countryinfoPanel to the rightside of the main panel

		return mainPanel;

	}

	/**
	 * user panel -Dynamic JComboBox to populate with user data from back end -5
	 * static JLabels (Username:, Email:, Phone:, Vaccination Stance:) -4 dynamic
	 * JLabels that update with UserComboBox and reflect selected user's data -2
	 * JButtons one to return to insert user panel ("Insert a User") and one that
	 * returns to main panel ("Back")
	 */
	JPanel selectionPanel, userPanel, topSelectionPanel, comboPanel, boxPanel, quesPanel, buttonsPanel, userInfoPanel,
			usernamePanel, emailPanel, phonePanel, stancePanel;

	String uString = "", eString = "", pString = "", sString = "";

	JLabel selectedUser, username, email, phone, userStance, usernameOut = new JLabel(uString),
			emailOut = new JLabel(eString), phoneOut = new JLabel(pString), stanceOut = new JLabel(sString);

	JButton insertUser, userBack;

	JComboBox userSelect;

	private JPanel UserPanel() {

		userPanel = new JPanel();
		userPanel.setLayout(new GridLayout(1, 2));
		//Creates a new panel with 1 row and 2 columns

		selectionPanel = new JPanel(new GridLayout(2, 1)); // right side of panel
		topSelectionPanel = new JPanel(new GridLayout(3, 1));// top half of right panel
		comboPanel = new JPanel(new FlowLayout());// holds combobox, put in topSelectionPanel
		boxPanel = new JPanel();
		quesPanel = new JPanel();
		//we initilize the JPanels, GridLayout and FlowLayout being used to make the program look neat

		userSelect = new JComboBox(listToArray(q.populateUsersCombo()));
		userSelect.setSelectedIndex(0);
		userSelect.addItemListener(this);
		//We fill in the JcomboBox with the usernameinfo and set it to the 0th position
		//we also add an itemlistener to update it when changed
		

		selectedUser = new JLabel("Selected User: ");
		//This is a Jabel displaying the words Selcted user

		quesPanel.add(selectedUser);
		comboPanel.add(quesPanel);
		boxPanel.add(userSelect);
		comboPanel.add(boxPanel);
		//We add the panels created to seperate panels, again to make it look neat

		topSelectionPanel.add(spacer);
		topSelectionPanel.add(comboPanel);
		//then add spacer and the combo panel to the top selection panel 

		selectionPanel.add(topSelectionPanel);
		//we add the top selection panel to the panel called select panel

		insertUser = new JButton("Inster User ");
		userBack = new JButton("Back");
		insertUser.addActionListener(this);
		userBack.addActionListener(this);
		//we create new buttons that will take us back to the previous card or to the add user card

		buttonPanel = new JPanel();
		

		buttonPanel.add(insertUser);
		buttonPanel.add(userBack);
		//we create and add these buttons to a button panel

		selectionPanel.add(buttonPanel);
		//we add the button panel to the selection panel
		userPanel.add(selectionPanel);
		//we add the selection panel to the userpanel

		userInfoPanel = new JPanel(new GridLayout(4, 1));
		// we create a new JPanel, with 4 rows and 1 column

		username = new JLabel("Username:     ");
		email = new JLabel("Email:        ");
		phone = new JLabel("Phone:        ");
		userStance = new JLabel("Stance:       ");
		//these are the static JLabels, needed to show what information is being displayed

		usernamePanel = new JPanel(new GridLayout(1, 2));
		emailPanel = new JPanel(new GridLayout(1, 2));
		phonePanel = new JPanel(new GridLayout(1, 2));
		stancePanel = new JPanel(new GridLayout(1, 2));
		//we cratePanels for each item of the items needed to be displayed

		usernamePanel.add(username);
		emailPanel.add(email);
		phonePanel.add(phone);
		stancePanel.add(userStance);
		//we add the static JLabels to the panels

		ArrayList info = q.fetchURecord((String) userSelect.getSelectedItem());
		//We create and arraylist to fetch the information needed to display 

		usernameOut = new JLabel((String) info.get(0));
		emailOut = new JLabel((String) info.get(1));
		phoneOut = new JLabel((String) info.get(2));
		stanceOut = new JLabel((String) info.get(3));
		//we set the dynamic JLabels to the information needed from the database

		usernamePanel.add(usernameOut);
		emailPanel.add(emailOut);
		phonePanel.add(phoneOut);
		stancePanel.add(stanceOut);
		//we add the dynamic JLabels to their panels

		userInfoPanel.add(usernamePanel);
		userInfoPanel.add(emailPanel);
		userInfoPanel.add(phonePanel);
		userInfoPanel.add(stancePanel);
		//we add all of the panels created to one central panel

		userPanel.add(userInfoPanel, BorderLayout.EAST);
		//we add this panel to the panel being displayed
		

		return userPanel;

	}

	
	/**
	 * insert user panel
	 * -5 Static JLabels (Add User:, Username:, Email:, Phone:, Vaccination Stance:)
	 * -4 JTextFields that take in values from user to go to back end as strings
	 * -2 Jbuttons one to execute the insert statement ("Insert") and one to go back to the users panel ("Back")
	 */
    JPanel returnPanel,
    	   leftPanel,
    	   rightPanel,
    	   addUserPanel,
		   iUsernamePanel,
		   iEmailPanel,
		   iPhonePanel,
		   iStancePanel,
    	   buttonPanel;
	
    JLabel addUser,
    	   iUsername,
		   iEmail,
		   iPhone,
		   iUserStance; 
    
	JButton insert,
			insertBack;
		   
    JTextField iUsernameField,
    			iEmailField,
    			iPhoneField,
    			iUserStanceField;
    
	private JPanel InsertUserPanel()
	{
		
		returnPanel = new JPanel( new GridLayout(1, 2) ); //complete panel that will be returned and displayed
		leftPanel = new JPanel( new GridLayout(5, 1) ); //left side of the returnPanel, hold textfields, userprompts and titles
		rightPanel = new JPanel( new GridLayout(3, 1) ); // right side of returnPanel, hold buttons to go back or insert user
		
		addUser = new JLabel("Add User"); //title displayed on top left
		addUser.setFont( new Font("Arial", Font.BOLD, 15 ));
		
		//user prompts for what they put in the textfields
 	    iUsername =   new JLabel("          Username: ");
		iEmail =      new JLabel("             Email: ");
		iPhone =      new JLabel("             Phone: ");
	    iUserStance = new JLabel("Vaccination Stance: ");
	    
	    //panels that the prompts and textfields will be placed on
	    addUserPanel = new JPanel( new FlowLayout() );	
		iUsernamePanel = new JPanel( new FlowLayout() );
		iEmailPanel = new JPanel( new FlowLayout() );
	    iPhonePanel = new JPanel( new FlowLayout() );
    	iStancePanel = new JPanel( new FlowLayout() );
    	
    	//creates textfields
		iUsernameField = new JTextField();
		iEmailField = new JTextField();
		iPhoneField = new JTextField();
		iUserStanceField = new JTextField();
		
		//sets textfields sizes
		iUsernameField.setPreferredSize( new Dimension( 100, 24 ) );
		iEmailField.setPreferredSize( new Dimension( 100, 24 ) );
		iPhoneField.setPreferredSize( new Dimension( 100, 24 ) );
		iUserStanceField.setPreferredSize( new Dimension( 100, 24 ) );
		
    	addUserPanel.add(addUser); //title to panel
    	
    	//adds prompts to panels
	    iUsernamePanel.add(iUsername);
	    iEmailPanel.add(iEmail);
   	    iPhonePanel.add(iPhone);
	    iStancePanel.add(iUserStance);
	    
	    //adds textfields to panel with corresponding prompt
	    iUsernamePanel.add(iUsernameField);
	    iEmailPanel.add(iEmailField);
   	    iPhonePanel.add(iPhoneField);
	    iStancePanel.add(iUserStanceField);
    	
	    //adds title and panels with prompts and text fields to left side
	    leftPanel.add( addUserPanel );
	    leftPanel.add( iUsernamePanel );
	    leftPanel.add( iEmailPanel );
	    leftPanel.add( iPhonePanel );
	    leftPanel.add( iStancePanel );
	    
	    //adds left panel to full return panel
	    returnPanel.add(leftPanel);
	    
	    //creates buttons
	    insert = new JButton( "Insert" ); //used to insert user (sends info to queries)
	    insertBack = new JButton( "Back" );//used to go to previous panel (user)
	    
	    //adds action
	    insert.addActionListener(this);
	    insertBack.addActionListener(this);
	    
	    buttonPanel = new JPanel( );//panel where buttons will go
	    
	    //adds buttons to panel
	    buttonPanel.add(insert); 
	    buttonPanel.add(insertBack);
	    
	    JPanel space = new JPanel();//blank panel to fill up a grid spot so buttons can be centered
	    
	    //places buttons in center of right panel
	    rightPanel.add(space);
	    rightPanel.add( buttonPanel);
	    
	    returnPanel.add(rightPanel);//adds right panel to full retrunPanel
	    
	    return returnPanel;
		
	}

	
	//UI triggers
	@Override
	
	/**
	 * Uses if statements to preform methods InsertButtonAction or adjustVisibilityActionButton based on
	 * where action came from
	 */
	public void actionPerformed(ActionEvent e) 
	{

		CardLayout c1 = (CardLayout)(panels.getLayout());
		
		if( e.getSource() == toUser )
		{
			
			//displays userPanel
			c1.show(panels, panelNames[1] );
			
		}
		else if( e.getSource() == userBack )
		{
			
			//displays MainPanel
			c1.show(panels, panelNames[0] );
			
		}
		else if( e.getSource() == insertBack )
		{
			
			//displayes userPanel
			c1.show(panels, panelNames[1] );
			
		}
		else if( e.getSource() == insert )
		{
			
			//stores user info from textfields in queries
			q.insertUserRecord(iUsernameField.getText(), iEmailField.getText(), iPhoneField.getText(), iUserStanceField.getText() ); 
			
			//resets textfields
			iUsernameField.setText(null); 
			iEmailField.setText(null); 
			iPhoneField.setText(null); 
			iUserStanceField.setText(null);
			
			//System.out.println(q.getUsername());
			//System.out.println(q.getEmail());
			//System.out.println(q.getPhone());
			//System.out.println(q.getStance());
			
		}
		else if( e.getSource() == insertUser )
		{
			
			c1.show(panels, panelNames[ 2 ] ); //displays insertUser panel
			
		}
	}
	
	
	ArrayList info;
	@Override
	public void itemStateChanged(ItemEvent e) 
	{
		
		if( e.getSource() == userSelect )
		{
			info = new ArrayList(); // will contain info on user recieved from queries
			info = q.fetchURecord( (String)userSelect.getSelectedItem() ); // populates array list wiht information on specific user
			
			//sets user info
			uString = (String) info.get(0);	
			eString = (String) info.get(1);	
			pString = (String) info.get(2);	
			sString = (String) info.get(3);	
			
			//updates display of info
			usernameOut.setText(uString);
			emailOut.setText( eString );
			phoneOut.setText( pString );
			stanceOut.setText( sString );
		}
		else if( e.getSource() == SelectCountryMenu )
		{
			info = new ArrayList();//will contain information on country recieved from queries
			info = q.fetchCRecord( (String)SelectCountryMenu.getSelectedItem() );//populates arraylist with country inofmation based on
			//country selected in combobox on MainPanel
			CountryString = (String)SelectCountryMenu.getSelectedItem();//Name of the country displayed at top
			
			//sets countries statistics
			ApprovalString = (String) info.get(1);
			ImportantString = (String) info.get(2);	
			SafeString = (String) info.get(3);	
			EffectiveString = (String) info.get(4);	
			
			//updates title
			CountrySelected.setText(CountryString);
			CountrySelected.setFont( new Font("Arial", Font.BOLD, 15 ));
			
			//updates statistics displayed
			ApprovalRatingAnswer.setText(ApprovalString);
		    ImportantForChildernAnswer.setText(ImportantString);
			SafeAnswer.setText(SafeString);
			EffectiveAnswer.setText(EffectiveString);
			
		}
		
		
	}
	
	
	public static void main(String[] args) 
	{
		
		  //creates window Containing UI
		   Main_UI frame = new Main_UI("Vaccination Culture Calculator");
	   	   frame.setVisible(true);
	   	   frame.setLocation(550, 500);
	   	   frame.setSize(700, 330);
	   	   
	}


	



		
	

}

