import java.awt.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.mysql.cj.Query;

public class Queries {
	/*
	 * Connection code
	 */
   public Connection getConnection(){
        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost/vaccination", "root","usTwistedPair2!");
        } catch (SQLException ex) {
            Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }
   
   /**
	 * Fetches data to populate the dynamic country labels
	 * @param country
	 * @return
	 */
   public ArrayList<String> fetchCRecord(String country){
	   /*
		 * We will use this method to fetch the Countries and compare it to the string selected in
		 * the database, We will then display the information that matches that information
		 * 
		 * Pre-Conditions:We will take in the a string, from the "currently selected" of the JComboBox
		 * 
		 * Post-Conditions:The Arraylist will be used to return the information about the country
		 * 
		 */
      Connection con = getConnection();
      Statement st;
      ResultSet rs;
      ArrayList<String> record = new ArrayList<String>();
       try {
           st = con.createStatement();
           rs = st.executeQuery("SELECT * FROM dummy_data WHERE Entity = \""+country+"\"");
           while(rs.next()){
        	   record.add(rs.getString(1));
        	   record.add(rs.getString(2));
        	   record.add(rs.getString(3));
        	   record.add(rs.getString(4));
        	   record.add(rs.getString(5));
           }
                      
       } catch (SQLException ex) {
           Logger.getLogger(Queries.class.getName()).log(Level.SEVERE, null, ex);
       }
      return record;
   }
   
	/**
	 * Fetches data that populate the dynamic country labels
	 * @return
	 */
   public ArrayList<String> populateCountryCombo(){
	   /*
		 * We will use this method to return an arraylist that will populate the Jcombobox with the Countries in the arraylist
		 * 
		 * Pre-condition:We will need some type of data base of countries;
		 * Post-Condtions:The arraylist will populate the Jcombobox with Countries
		 */
		  ArrayList<String> countryList = new ArrayList<String>();
	      Connection con = getConnection();
	      Statement st;
	      ResultSet rs;
	      
	       try {
	           st = con.createStatement();
	           rs = st.executeQuery("SELECT Entity FROM sa_safe");
	           String country;
	           
	           while(rs.next()){
	               country = (rs.getString(1));
	               countryList.add(country);
	           }
	           
	       } catch (SQLException ex) {
	           Logger.getLogger(Queries.class.getName()).log(Level.SEVERE, null, ex);
	       }
	      return countryList;
	   }
	/**
	 * Fetches the usernames for the Users ComboBox
	 * @return
	 */
   public ArrayList<String> populateUsersCombo(){
		/*
		 * We will use this method to return an arraylist that will populate the Jcombobox with the names in the arraylist
		 * 
		 * Pre-condition:We will need some type of data base of users;
		 * Post-Condtions:The arraylist will populate the Jcombobox with usernames
		 */

	   ArrayList<String> userList = new ArrayList<String>();
	      Connection con = getConnection();
	      Statement st;
	      ResultSet rs;
	      
	       try {
	           st = con.createStatement();
	           rs = st.executeQuery("SELECT Username FROM users");
	           String User;
	           
	           while(rs.next()){
	               User = (rs.getString(1));
	               userList.add(User);
	           }
	           
	       } catch (SQLException ex) {
	           Logger.getLogger(Queries.class.getName()).log(Level.SEVERE, null, ex);
	       }
	      return userList;
   }
   
	/**
	 * Fetches data that will populate the dynamic user labels
	 * @param username
	 * @return
	 */
   public ArrayList<String> fetchURecord(String username){
	   /*
		 * We will use this method to fetch the usernames and compare it to the usernames in
		 * the arraylist, We will then display the information that matches that information
		 * 
		 * Pre-Conditions:We will take in the a string, from the currently selected of the JComboBox
		 * 
		 * Post-Conditions:The Arraylist will be used to return the information from the username
		 * 
		 */
	      Connection con = getConnection();
	      Statement st;
	      ResultSet rs;
	      ArrayList<String> record = new ArrayList<String>();
	       try {
	           st = con.createStatement();
	           rs = st.executeQuery("SELECT * FROM users WHERE Username = \""+username+"\"");
	           while(rs.next()){
	        	   record.add(rs.getString(1));
	        	   record.add(rs.getString(2));
	        	   record.add(rs.getString(3));
	        	   record.add(rs.getString(4));
	           }
	                      
	       } catch (SQLException ex) {
	           Logger.getLogger(Queries.class.getName()).log(Level.SEVERE, null, ex);
	       }
	      return record;
	   }
	/**
	 * Creates and sends off insert statements to back end
	 * @param username
	 * @param email
	 * @param phone
	 * @param stance
	 */
   public void insertUserRecord(String Username, String Email, String Phone, String Stance){
	   /*
		 * We use this method to set the the variables, the username, email, phone, and
		 * stance, which will then be displayed later
		 * 
		 * Pre-Condition: We take a username, email, phone number, and stance on
		 * vaccination.
		 * 
		 * Post-Conditions:This sets the username, email, phone number and stance on
		 * vaccination
		 */
	      Connection con = getConnection();
	      Statement st;
	      ResultSet rs;
	      System.out.println(Username);
	      System.out.println(Email);
	      String query = "INSERT INTO users VALUES (\""+Username+"\",\""+Email+"\",\""+Phone+"\",\""+Stance+"\")";
	      System.out.println(query);
	      PreparedStatement preparedStmt = null;
		try {
			preparedStmt = con.prepareStatement(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      try {
			preparedStmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   }
}