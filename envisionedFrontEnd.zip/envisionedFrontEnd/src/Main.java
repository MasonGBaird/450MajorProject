import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.FlowLayout;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import java.awt.CardLayout;
import java.awt.GridLayout;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Main extends JFrame {
	
	private JPanel contentPane;
	private JTextField txtStance;
	private JTextField txtPhone;
	private JTextField txtEmail;
	private JTextField txtUsername;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		Queries mq = new Queries();
		setTitle("Vaccination Culture Calculator");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 884, 360);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0));
		
		//Main Panel Code
		JPanel Main = new JPanel();
		contentPane.add(Main, "name_1561529885745657");
		Main.setLayout(null);
		
		JLabel label = new JLabel("Select Country:");
		label.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label.setBounds(53, 88, 114, 32);
		Main.add(label);
		
		//Dynamic Labels
				JLabel lblCountry = new JLabel("Select Country");
				lblCountry.setFont(new Font("Tahoma", Font.BOLD, 16));
				lblCountry.setBounds(572, 23, 161, 32);
				Main.add(lblCountry);
				
				JLabel lblApprovalRating = new JLabel("Select Country");
				lblApprovalRating.setFont(new Font("Tahoma", Font.PLAIN, 16));
				lblApprovalRating.setBounds(646, 68, 172, 32);
				Main.add(lblApprovalRating);
				
				JLabel lblSAsafe = new JLabel("Select Country");
				lblSAsafe.setFont(new Font("Tahoma", Font.PLAIN, 16));
				lblSAsafe.setBounds(645, 113, 161, 32);
				Main.add(lblSAsafe);
				
				JLabel lblSAeffective = new JLabel("Select Country");
				lblSAeffective.setFont(new Font("Tahoma", Font.PLAIN, 16));
				lblSAeffective.setBounds(645, 161, 137, 32);
				Main.add(lblSAeffective);
				
				JLabel lblSDeffective = new JLabel("Select Country");
				lblSDeffective.setFont(new Font("Tahoma", Font.PLAIN, 16));
				lblSDeffective.setBounds(646, 206, 107, 32);
				Main.add(lblSDeffective);
		//dynamic labels end
				
		JComboBox cmbxCountry = new JComboBox();
		cmbxCountry.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent selectionChange) {
				//label program

			    ArrayList<String> Mrecord = mq.fetchCRecord(cmbxCountry.getSelectedItem().toString());
				//dynamic label sets
			    lblCountry.setText(Mrecord.get(0));
			    lblApprovalRating.setText(Mrecord.get(1));
			    lblSAsafe.setText(Mrecord.get(2));
			    lblSAeffective.setText(Mrecord.get(3));
			    lblSDeffective.setText(Mrecord.get(4));
			}
		});
		cmbxCountry.setBounds(178, 94, 229, 22);
		Main.add(cmbxCountry);
		
		ArrayList<String> countryList = mq.populateCountryCombo();
		
		//adding data to country combo box
	    for(String s : countryList){
	    		cmbxCountry.addItem(s);
	    	}
	    
	    //static labels
		JLabel label_1 = new JLabel("SA Important for Children:");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_1.setBounds(444, 116, 201, 32);
		Main.add(label_1);
		
		JLabel label_2 = new JLabel("Approval Rating [-10 - 10]:");
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_2.setBounds(444, 68, 201, 32);
		Main.add(label_2);
		
		JLabel label_8 = new JLabel("SA Safe:");
		label_8.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_8.setBounds(572, 161, 61, 32);
		Main.add(label_8);
		
		JLabel label_9 = new JLabel("SD Effective:");
		label_9.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_9.setBounds(542, 206, 92, 32);
		Main.add(label_9);
		JButton btnSeeinsertUsers = new JButton("See or Insert Users");
		btnSeeinsertUsers.setBounds(108, 146, 161, 41);
		Main.add(btnSeeinsertUsers);
		//end Main Panel code
		
		//Users Panel code
		JPanel Users = new JPanel();
		contentPane.add(Users, "name_1561533233310376");
		Users.setLayout(null);
		
		JButton btnInsertLink = new JButton("Insert a User");
		
		btnInsertLink.setBounds(36, 93, 107, 25);
		Users.add(btnInsertLink);
		
		JButton btnUsersBack = new JButton("Back");
		btnUsersBack.setBounds(174, 93, 97, 25);
		Users.add(btnUsersBack);
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setBounds(324, 29, 74, 25);
		Users.add(lblUsername);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setBounds(355, 56, 36, 16);
		Users.add(lblEmail);
		
		JLabel lblPhone = new JLabel("Phone:");
		lblPhone.setBounds(352, 85, 46, 16);
		Users.add(lblPhone);
		
		JLabel lblUserStance = new JLabel("Vaccination Stance:");
		lblUserStance.setBounds(280, 114, 127, 16);
		Users.add(lblUserStance);
		
		JLabel lblSelectedUser = new JLabel("Selected User:");
		lblSelectedUser.setBounds(12, 29, 97, 40);
		Users.add(lblSelectedUser);
		
		JLabel lbldynoUsername = new JLabel("New label");
		lbldynoUsername.setBounds(403, 33, 136, 16);
		Users.add(lbldynoUsername);
		
		JLabel lbldynoEmail = new JLabel("New label");
		lbldynoEmail.setBounds(403, 56, 170, 16);
		Users.add(lbldynoEmail);
		
		JLabel lbldynoPhone = new JLabel("New label");
		lbldynoPhone.setBounds(403, 85, 170, 16);
		Users.add(lbldynoPhone);
		
		JLabel lbldynoStance = new JLabel("New label");
		lbldynoStance.setBounds(403, 114, 170, 16);
		Users.add(lbldynoStance);
		
		JComboBox cmbxUsers = new JComboBox();
		cmbxUsers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//label program	    
			    ArrayList<String> Urecord = mq.fetchURecord(cmbxUsers.getSelectedItem().toString());
				//dynamic label sets
			    lbldynoUsername.setText(Urecord.get(0));
			    lbldynoEmail.setText(Urecord.get(1));
			    lbldynoPhone.setText(Urecord.get(2));
			    lbldynoStance.setText(Urecord.get(3));
			}
		});
		cmbxUsers.setBounds(101, 38, 179, 22);
		Users.add(cmbxUsers);
		ArrayList<String> userList = mq.populateUsersCombo();
		
		//adding data to users combo box
	    for(String s : userList){
	    		cmbxUsers.addItem(s);
	    	}
		//Users Panel code end
		
		//InsertUser Panel		
		JPanel InsertUser = new JPanel();
		contentPane.add(InsertUser, "name_1561535519963812");
		InsertUser.setLayout(null);
		
		JLabel label_3 = new JLabel("Add User:");
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		label_3.setBounds(12, 23, 107, 43);
		InsertUser.add(label_3);
		
		JLabel lblUsernamet = new JLabel("Username:");
		lblUsernamet.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblUsernamet.setBounds(119, 26, 107, 16);
		InsertUser.add(lblUsernamet);
		
		JLabel label_12 = new JLabel("Email:");
		label_12.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label_12.setBounds(119, 55, 107, 16);
		InsertUser.add(label_12);
		
		JLabel label_13 = new JLabel("Phone:");
		label_13.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label_13.setBounds(119, 84, 107, 16);
		InsertUser.add(label_13);
		
		JLabel lblStancetxtbox = new JLabel("Vaccination Stance:");
		lblStancetxtbox.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblStancetxtbox.setBounds(119, 113, 141, 16);
		InsertUser.add(lblStancetxtbox);
		
		txtStance = new JTextField();
		txtStance.setColumns(10);
		txtStance.setBounds(269, 110, 116, 22);
		InsertUser.add(txtStance);
		
		txtPhone = new JTextField();
		txtPhone.setColumns(10);
		txtPhone.setBounds(269, 81, 116, 22);
		InsertUser.add(txtPhone);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(269, 52, 116, 22);
		InsertUser.add(txtEmail);
		
		txtUsername = new JTextField();
		txtUsername.setColumns(10);
		txtUsername.setBounds(269, 23, 116, 22);
		InsertUser.add(txtUsername);
		
		JButton btnInsertq = new JButton("Insert");
		//insert
		btnInsertq.addActionListener(new ActionListener() {
			String ID, Username, Email, Phone, Stance;
			public void actionPerformed(ActionEvent e) {
				Username = txtUsername.getText();
				Email = txtEmail.getText();
				Phone = txtPhone.getText();
				Stance = txtStance.getText();
				mq.insertUserRecord(Username,Email,Phone,Stance);
			}
		});
		btnInsertq.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnInsertq.setBounds(444, 75, 148, 31);
		InsertUser.add(btnInsertq);
		
		JButton btnInsertBack = new JButton("Back");
		btnInsertBack.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnInsertBack.setBounds(633, 75, 185, 31);
		InsertUser.add(btnInsertBack);
		//InsertUser Panel end
		
		//cross panel action listeners
		// Main -> Users
		btnSeeinsertUsers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Users.setVisible(true);
				Main.setVisible(false);
				InsertUser.setVisible(false);
			}
		});
		//Users -> InsertUser
		btnInsertLink.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Users.setVisible(false);
				Main.setVisible(false);
				InsertUser.setVisible(true);
			}
		});
		//Users -> Main
		btnUsersBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Users.setVisible(false);
				Main.setVisible(true);
				InsertUser.setVisible(false);
			}
		});
		//InsertUser -> Users
		btnInsertBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Users.setVisible(true);
				Main.setVisible(false);
				InsertUser.setVisible(false);
			}
		});

	}
}
